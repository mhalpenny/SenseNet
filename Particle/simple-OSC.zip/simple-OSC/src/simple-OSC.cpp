#include "application.h"
#line 1 "/Users/Matthew/Developer/Particle/simple-OSC/src/simple-OSC.ino"
void setup();
void loop();
boolean bang();
#line 1 "/Users/Matthew/Developer/Particle/simple-OSC/src/simple-OSC.ino"
SYSTEM_THREAD(ENABLED);
SYSTEM_MODE(SEMI_AUTOMATIC);

/* IF USING MAX-MSP - THEN THIS */
#include "simple-OSC.h"

/* FLASHING CODE TO PARTICLE - 3 OPTIONS 
  a) PARTICLE CONNECTED TO CLOUD
    particle flash YOUR_DEVICE_NAME target/blinkled.bin
  b) PARTICLE DFU MODE (blinking yellow)
    particle flash --usb target/blinkled.bin
  c) PARTICLE LISTENING MODE (blinking dark blue):
    particle flash --serial target/blinkled.bin
*/

/* FINDING PARTICLE DEVICE INFORMATION - PARTICLE LISTENING MODE
  particle identify 
*/

/* PHOTON WiFi MEMORY 
  Photon: remembers the 5 most recently set credentials
  WiFi.setCredentials(ssid, password);
  WiFi.setCredentials("My_Router", "mypasswordishuge");
*/

// UDP Port used for two way communication
unsigned int localPort = 8888;
//IPAddress multicastAddress(224,0,0,0);
IPAddress ipAddress;
int port;

// An UDP instance to let us send and receive packets over UDP
UDP udp;

/* ONBOARD LED = DEBUG LED */
#define DEEBUG 7

/* OPTIONAL -> NEED TO CHECK CLOUD CONNECTION */
boolean cloudConnected = false;



int myntOnePowerPin = D5;
int myntOnePlusPin = D6;
int myntOneMinusPin = D7;

int myntTwoPowerPin = D2;
int myntTwoPlusPin = D3;
int myntTwoMinusPin = D4;

unsigned long eventStartA = 0;
unsigned long  eventStartB = 0;
unsigned long lastTime = 0;
bool eventCompleteA = false;
bool eventCompleteB = false;

int flexSensePin1 = A1;

int flexValue1;

int flexSensePin2 = A0;

int flexValue2;

int valA = 0; 
int tempA = 0;
int valB= 0; 
int tempB = 0;

int sendVal = 0;
int sendVal2 = 0;

 int bendArrayA[31];
int averageA = 0;
int oldAverageA = 0;

 int bendArrayB[31];
int averageB = 0;
int oldAverageB = 0;


unsigned long nowA  = 0; //this variable will be overwritten by millis() each iteration of loop
unsigned long lastTimeA   = 0; //no time has passed yet

bool allowA = true;




void PING(OSCMessage &inMessage);

void setup()
{
    Serial.begin(115200);
    while(!Serial);

    pinMode(DEEBUG, OUTPUT);
    Serial.println("INIT");

    /* IF NOT CONFIGURED FOR ROUTER - THEN THIS */
    //WiFi.setCredentials("My_Router", "mypasswordishuge");

    /* IF ALREADY CONFIGURED FOR SPECFIC ROUTER - THEN THIS */
    WiFi.connect();
    while(!WiFi.ready());
    /* SET STATIC IP ADDRESS - IF DHCP NOT ENABLED ON ROUTER */
    //IPAddress myAddress(10,0,1,30);
    //IPAddress netmask(255,255,255,0);
    //IPAddress gateway(10,0,1,1);
    //IPAddress dns(10,0,1,1);

    /* SET IT UP */
    //WiFi.setStaticIP(myAddress, netmask, gateway, dns);
    udp.begin(localPort);
    //Udp.joinMulticast(multicastAddress);
    /* SET HOSTNAME */
    WiFi.setHostname("basophil");
    Serial.println(WiFi.hostname());
    Serial.println(WiFi.localIP());


pinMode(myntOnePowerPin, OUTPUT);
pinMode(myntOnePlusPin, OUTPUT);
pinMode(myntOneMinusPin, OUTPUT);
pinMode(myntTwoPowerPin, OUTPUT);
pinMode(myntTwoPlusPin, OUTPUT);
pinMode(myntTwoMinusPin, OUTPUT);

digitalWrite(myntOnePowerPin, HIGH);
digitalWrite(myntOnePlusPin, HIGH);
digitalWrite(myntOneMinusPin, HIGH);
digitalWrite(myntTwoPowerPin, HIGH);
digitalWrite(myntTwoPlusPin, HIGH);
digitalWrite(myntTwoMinusPin, HIGH);
}

void loop()
{
    
    //RECEIVE
    int size = 0;
    OSCMessage inMessage;
    if ( ( size = udp.parsePacket()) > 0)
    {

      // Read first char of data received
      //char c = udp.read();
      digitalWrite(DEEBUG, HIGH);
      delay(5);
      digitalWrite(DEEBUG, LOW);
      delay(5);

      //Serial.println(c, DEC);
      // Store sender ip and port
      // ipAddress = udp.remoteIP();
      // port = udp.remotePort();

        /* REQUIRES CORRECTLY FORMATTED OSC MSG */
        // while (size--)
        // {
        //     inMessage.fill(udp.read());
        // }
        // if( inMessage.parse())
        // {
        //     inMessage.route("/ping", PING);
        // }
    }
    
    /* COLLATE AND SEND TO MAX */
    int stat = bang();
    if(!stat); /* ERROR */



    //read current time off millis()
    nowA = millis();

    valA = analogRead(flexSensePin1); //read value of flex rubber sensor
    // val = averageSensor(flexSensePin1);
     for ( int i = 0; i < 32; i++){
         bendArrayA[i]=valA;
     }
     
     for (int i = 0; i < 32; i++){
         averageA += bendArrayA[i];
     }
     averageA = averageA/32;
     if((millis() % (unsigned long )1000 )  == 0) {
     oldAverageA = averageA;
     }
     
     if(averageA < (oldAverageA-300)){
         
         if(eventCompleteA == true){
             eventStartA = millis();  
             }
         
         eventCompleteA = false;
        
          
         
            }
     
        //last value buffer
        // oldAverageA = averageA;
        
        //          Serial.print("A: ");
        // Serial.println(averageA);
        //     Serial.print("OLD: ");
        // Serial.println(oldAverageA);
        
    
if(!eventCompleteA){
    Serial.print("loop: ");
    Serial.println(millis());
    
    if(millis() < (eventStartA + (unsigned long) 2000)){
        digitalWrite(myntOnePowerPin, LOW);
        Serial.println("digitalWrite(myntOnePowerPin, LOW;");
    }else if(millis() > (eventStartA + (unsigned long) 2000) && millis() < (eventStartA + (unsigned long) 3000)){
        digitalWrite(myntOnePowerPin, HIGH);
        Serial.println("digitalWrite(myntOnePowerPin, HIGH;");
    }
    
    if(millis() > (eventStartA + (unsigned long) 2050) && millis() < (eventStartA + (unsigned long) 2350)){
        digitalWrite(myntOnePlusPin, LOW);
        Serial.println(" digitalWrite(myntOnePlusPin, LOW;");
    }else if(millis() > (eventStartA + (unsigned long) 2350) && millis() < (eventStartA + (unsigned long) 2600)){
        digitalWrite(myntOnePlusPin, HIGH);
        Serial.println("digitalWrite(myntOnePlusPin, HIGH");
    }
    
    if(millis() > (eventStartA + (unsigned long) 2400) && millis() < (eventStartA + (unsigned long) 2600)){
        digitalWrite(myntOnePlusPin, LOW);
        Serial.println(" digitalWrite(myntOnePlusPin, LOW;");
    }else if(millis() > (eventStartA + (unsigned long) 2600) && millis() < (eventStartA + (unsigned long) 2800)){
        digitalWrite(myntOnePlusPin, HIGH);
        Serial.println("digitalWrite(myntOnePlusPin, HIGH");
    }
    
    if(millis() > (eventStartA + (unsigned long) 4000) && millis() < (eventStartA + (unsigned long) 6000)){
        digitalWrite(myntOnePowerPin, LOW);
        Serial.println("digitalWrite(myntOnePowerPin, LOW;");
    }else if(millis() > (eventStartA + (unsigned long) 6000) && millis() < (eventStartA + (unsigned long) 7000)){
        digitalWrite(myntOnePowerPin, HIGH);
        Serial.println("digitalWrite(myntOnePowerPin, HIGH");
    }
    
    if(millis() > (eventStartA + (unsigned long) 7000)){
        eventCompleteA = true;
        Serial.println("end");
    }
    
}
Serial.println(WiFi.localIP());
}

void PING(OSCMessage &inMessage)
{
    Serial.println("RE OSC MESG");
}

boolean bang() {
  /* GET 9DOF DATA AND POPULATE OSC MESSAGE */

  /* START OSC MSG NAMESPACE */
  OSCMessage outMessage("/zang");
  /* OSC DATA */ 
  outMessage.addString("a");
  outMessage.addFloat(-3.14); 
  outMessage.addInt(-1);
  /* BANG TO MAX */
  outMessage.send(udp,ipAddress,8889);

  return 1;
}
